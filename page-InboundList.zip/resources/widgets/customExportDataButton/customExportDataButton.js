(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customExportDataButton', function() {
    return {
      controllerAs: 'ctrl',
      controller: function exportDataButton($scope) {
    
    $scope.addHeader = 0;
    $scope.export = function() {
        
        console.log($scope.properties.data);
       var items = $scope.properties.data;

        //file name
        var fileTitle = $scope.properties.filename; 
        
        if ( $scope.addHeader ++ === 0) {
            items.unshift($scope.properties.headers);
            console.log(items);
        }
        
        // Convert Object to JSON
        var jsonObject = JSON.stringify(items);
        var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;
        var csv = '';
        for (var i = 0; i < array.length; i++) {
            var line = '';
            for (var index in array[i]) {
                if (line !== '') line += ','
        
                line += array[i][index];
            }
        
            csv += line + '\r\n';
        }
        
        var exportedFilenmae = fileTitle + '.csv' || 'export.csv';
        
        var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        if (navigator.msSaveBlob) { // IE 10+
            navigator.msSaveBlob(blob, exportedFilenmae);
        } else {
            var link = document.createElement("a");
            if (link.download !== undefined) { // feature detection
                // Browsers that support HTML5 download attribute
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", exportedFilenmae);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
        items = [];
    };
    
},
      template: '<div class="text-{{ properties.alignment }}">\n    <button\n        type="button"\n        ng-class="\'btn btn-\' + properties.buttonStyle"\n        ng-click="export()"\n        ng-disabled="properties.disabled">{{ properties.label | uiTranslate }}</button>\n</div>'
    };
  });
